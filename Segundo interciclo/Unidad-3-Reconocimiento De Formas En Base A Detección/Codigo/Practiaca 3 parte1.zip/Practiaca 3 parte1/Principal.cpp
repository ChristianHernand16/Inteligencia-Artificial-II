
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cmath>

//#include <opencv2/opencv.hpp>

#include <opencv2/core.hpp> 
#include <opencv2/highgui/highgui.hpp> 
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/imgcodecs/imgcodecs.hpp>
#include <opencv2/video/video.hpp>
#include <opencv2/videoio/videoio.hpp>

using namespace cv;
using namespace std;
Mat frame;
Mat sal;
Mat pimienta;

Mat mediana;
Mat blurv;
Mat gaussiano;
        
Mat laplace;
Mat canny;
Mat sobel;

int salV = 0;
int pimientaV = 0;


void functionTrackS(int v, void *p){
    cout << "Sal: " << v << endl;
}
void functionTrackP(int v, void *p){
    cout << "Pimienta: " << v << endl;
}


int main(int argc, char *argv[]){
    
    VideoCapture video("./goku.mp4");
    
    

    if(video.isOpened()){
      
        
        namedWindow("Video",WINDOW_AUTOSIZE);
        createTrackbar("Sal: ", "Video", &salV, 100, functionTrackS, NULL);
        createTrackbar("Pimienta: ", "Video", &pimientaV, 100, functionTrackP, NULL);

        
        while(3==3){
            video >> frame;

            if(!frame.empty()){
                cvtColor(frame, frame, COLOR_BGR2GRAY);

                resize(frame, frame, Size(500,350));
                sal=frame.clone();
                pimienta=frame.clone();

                //Aplicando filtos de Sal
                int sx=0, sy=0;
                double porcentajeS = (double)salV/100;
                int totalS = ((int)(porcentajeS * ((double) frame.rows*frame.cols)));
                
                while(totalS>0){
                    sx = rand() % frame.cols;
                    sy = rand() % frame.rows;
                    sal.at<uchar>(sy,sx) = 255;
                    totalS--;
                }

                //Apliacando filtro de Pimienta
               int px=0, py=0;
                double porcentajeP = (double)pimientaV/100;
                int totalP = ((int)(porcentajeP * ((double) frame.rows*frame.cols)));
                
                while(totalP>0){
                    px = rand() % frame.cols;
                    py = rand() % frame.rows;
                    pimienta.at<uchar>(py,px) = 0;
                    totalP--;
                }
                
                //Aplicacion de Filtros
                //Mediana
                
                medianBlur(pimienta,mediana,7);
               // medianBlur(sal,mediana,31);
                //medianBlur(sal,mediana,55);
                
                
                //Blur
                
                blur(pimienta,blurv, Size(7,7));
               //blur(sal,blurv, Size(21,21));
                //blur(sal,blurv, Size(45,45));
                
                //Aplicaccion de filtro gaussiano
                
                GaussianBlur(pimienta,gaussiano,Size(),7);
                //GaussianBlur(pimienta,gaussiano,Size(),21);
               //GaussianBlur(pimienta,gaussiano,Size(),33);
                
               
               //Apliacando deteccion de Bordes
               
               int tresh =30;
               
               
               
               Canny(gaussiano, canny, tresh,tresh*5,5);
               Laplacian(blurv,laplace,CV_8UC1,5);
               Sobel(mediana,sobel,CV_8UC1,3,0,9);
               
               imshow("Video", frame);                
               imshow("Sal", sal);
               imshow("Pimienta", pimienta);
                
                
                imshow("Mediana", mediana);
                
                imshow("Blur", blurv);
            
                imshow("Gaussiano", gaussiano);
                imshow("Canny",canny);
                
                imshow("Laplace",laplace);
                imshow("Sobel",sobel);

                
                if(waitKey(100)==27)
                    break;
            }else
                break;
        }
    }
    destroyAllWindows();
    return 0;
}





