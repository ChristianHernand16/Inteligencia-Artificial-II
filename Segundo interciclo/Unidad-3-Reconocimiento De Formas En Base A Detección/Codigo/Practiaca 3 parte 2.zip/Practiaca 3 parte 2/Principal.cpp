#include <iostream>
#include <fstream>
#include <opencv2/opencv.hpp>

using namespace cv;

int main(int argc, char** argv )
{
    Mat src, dst,dst1,dst2 ,dst3, kernel,kernel1; 

    src = cv::imread("imagen3.jpg");
     resize(src, src, Size(),1,1);
  
    
    //Dilatacion
    kernel = cv::getStructuringElement(MORPH_RECT, Size(5, 5));
    cv::dilate(src, dst, kernel);
    
    //Erosion
    kernel = cv::getStructuringElement(MORPH_ELLIPSE, Size(3, 3));
   cv::erode(src, dst1, kernel);
    
    
    //TOP HAT
   cv::morphologyEx(src, dst2, MORPH_TOPHAT, kernel1);
    
    //TOP BLACK
   cv::morphologyEx(src, dst3, MORPH_BLACKHAT, kernel1);
   
  
    cv::imshow("Original", src);
    cv::imshow("Dilatacion", dst);
    cv::imshow("Erosion", dst1);
    cv::imshow("Top Hat", dst2);
    cv::imshow("Black Hat", dst2);
    cv::waitKey(0);
  destroyAllWindows(); 
    return 0;
}
